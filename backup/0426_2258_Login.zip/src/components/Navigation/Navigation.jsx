import React from 'react'
import { Link } from 'react-router-dom'

export default function Navigation() {
    return (
        <div className='navigation'>
            <div className="naviLeft">
                <a href=" ">shop</a>
                <Link to='/about'>About Us</Link>
            </div>
            <div className="naviCenter">
                <div><Link to='/'></Link></div>
            </div>
            <div className="naviRight">
                <div>search</div>
                <div><Link to='/cart'>Cart</Link></div>
                <div><Link to='/login'>Login</Link></div>
            </div>
        </div>
    )
}
