import React from 'react'
import { Link } from 'react-router-dom'
import Navigation from '../../components/Navigation/Navigation.jsx'
import { useSelector } from 'react-redux'



export default function Cart() {
    const {items, total} = useSelector((state)=> state.cart)
    return (
        <div>
            <Navigation></Navigation>
        </div>
    )
}
