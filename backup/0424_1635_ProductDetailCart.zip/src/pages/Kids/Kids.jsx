import React from 'react'
import { Link, useParams } from 'react-router-dom'
import ProductSelect from '../../components/ProductSelect/ProductSelect.jsx'
import { kids } from '../../api/shoeList.js'



export default function Kids() {
    const { id } = useParams();
    // console.log(id);

    return (
        <div>
            <ProductSelect data={kids}></ProductSelect>
        </div>
    )
}
