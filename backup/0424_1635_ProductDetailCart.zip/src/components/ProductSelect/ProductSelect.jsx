import React from 'react'
import './ProductSelect.scss'
import { Link } from 'react-router-dom'
import Navigation from '../../components/Navigation/Navigation.jsx'



export default function ProductSelect(props) {
    const item = props.data.products
    return (
        <div>
            <Navigation></Navigation>
            <ul className='productList'>
                {item.map((product) => (
                    <li className='productItem' key={product.id}>
                        <a href={`/ProductDetail/${product.id} `} className='itemImg'>
                            <img src={product.img} alt={product.title} />
                        </a>
                        <a href={`/ProductDetail/${product.id} `} className="itemTitle">{product.title}</a>
                        <p className='itemPrice'>${product.price}</p>
                    </li>
                ))}
            </ul>
        </div>
    )
}
