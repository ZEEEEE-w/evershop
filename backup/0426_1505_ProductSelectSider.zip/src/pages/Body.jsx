import React from 'react'

export default function Body() {
    return (
        <div>
            <h2>Body</h2>
        </div>
    )
}
