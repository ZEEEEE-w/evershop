import React from 'react'
import { Link } from 'react-router-dom'

export default function Navigation() {
    return (
        <div className='navigation'>
                <div className="naviLeft">
                    <a href=" ">shop</a>
                    <Link to='/about'>About Us</Link>
                </div>
                <div className="naviCenter">
                    <a href="/"></a>
                </div>
                <div className="naviRight">
                    <div>search</div>
                    <div><Link to='/cart'>Cart</Link></div>
                    <div><Link to='/login'><a>Login</a></Link></div>
                </div>
            </div>
    )
}
