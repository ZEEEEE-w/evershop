import React from 'react'
import './ProductSelect.scss'
import Navigation from '../../components/Navigation/Navigation.jsx'
import { Slider, Divider, Checkbox } from 'antd';

export default function ProductSelect(props) {
    //Product Items
    const item = props.data.products

    //sort items 
    const maxPrice = Math.max(...item.map(product => product.price));
    const minPrice = Math.min(...item.map(product => product.price));
    console.log(maxPrice, minPrice);
    

    const priceOnChange = value => {
        console.log('onChange: ', value);
    };
    const priceOnChangeComplete = value => {
        console.log('onChangeComplete: ', value);
    };
    const sizeOnChange = checkedValues => {
        console.log('checked = ', checkedValues);
    };
    const plainOptions = ['Apple', 'Pear', 'Orange'];

    
    return (
        <div>
            <Navigation></Navigation>
            <div className="selectContainer">
                <nav className="breadcrumb">
                    <a href="/">Home</a> / <a href={`/${props.data.id}`}>{props.data.id}</a>
                </nav>
                <h1>{props.data.id}</h1>
                <div className="content">
                    <div className="sider">
                        <h3>Sort By</h3>
                        <p>Price</p>
                        <Slider
                            range
                            min = {minPrice}
                            max = {maxPrice}
                            step={10}
                            defaultValue={[minPrice, maxPrice]}
                            onChange={priceOnChange}
                            onChangeComplete={priceOnChangeComplete}
                        />
                        <div className="priceRange">
                            <span >${priceOnChange}</span>
                            <span >${priceOnChange}</span>
                        </div>
                        <p>SIZE</p>
                        <Divider style={{ margin: '0' }} />
                        <Checkbox.Group options={plainOptions} defaultValue={['Apple']} onChange={sizeOnChange} style={{flexDirection : 'column'}}/>
                        <p>COLOR</p>
                        <Divider style={{ margin: '0' }} />
                        <Checkbox.Group options={plainOptions} defaultValue={['Apple']} onChange={sizeOnChange} style={{flexDirection : 'column'}}/>
                        <p>BRAND</p>
                        <Divider style={{ margin: '0' }} />
                        <Checkbox.Group options={plainOptions} defaultValue={['Apple']} onChange={sizeOnChange} style={{flexDirection : 'column'}}/>
                    </div>
                    <ul className='productList'>
                        {item.map((product) => (
                            <li className='productItem' key={product.id}>
                                <a href={`/ProductDetail/${product.id} `} className='itemImg'>
                                    <img src={product.img} alt={product.title} />
                                </a>
                                <a href={`/ProductDetail/${product.id} `} className="itemTitle">{product.title}</a>
                                <p className='itemPrice'>${product.price}</p>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

        </div>
    )
}
