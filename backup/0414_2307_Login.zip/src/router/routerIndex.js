import Layout from "../pages/Layout";
import NotFound from "../pages/NotFound";
import Login from "../pages/Login";
import Women from "../pages/Women";
import Men from "../pages/Men";
import Kids from "../pages/Kids";
import Body from "../pages/Body";
import Cart from "../pages/Cart";


const router = [

    {
        path: '/',
        element: <Layout />,
        children:[
            {
                element: <Body />,
                index: true
            }
        ]
    },
    {
        path: '/women',
        element: <Women />
    },
    {
        path: '/men',
        element: <Men />
    },
    {
        path: '/kids',
        element: <Kids />
    },
    {
        path: '/login',
        element: <Login />
    },
    {
        path: '/cart',
        element: <Cart />
    },
    {
        path: '*',
        element: <NotFound />
    },
]

export default router;