import React from 'react'
import { Outlet,Link } from 'react-router-dom'

export default function Layout() {
    return (
        <div>
            <h1>EverShop</h1>
            <Outlet/>
            <Link to='/women'><button>Shop Women</button></Link>
            <Link to='/men'><button>Shop Men</button></Link>
            <Link to='/kids'><button>Shop Kids</button></Link>
            <Link to='/login'><button>Login</button></Link>
            <Link to='/cart'><button>Cart</button></Link>
        </div>
    )
}
