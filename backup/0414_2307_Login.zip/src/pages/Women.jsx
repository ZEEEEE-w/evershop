import React from 'react'
import { Link } from 'react-router-dom'

export default function Women() {
  return (
    <div>
        <h1>Shop Women</h1>
        <Link to='/'><button>Home</button></Link>
    </div>
  )
}
