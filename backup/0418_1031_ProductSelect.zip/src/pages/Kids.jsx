import React from 'react'
import { Link, useParams } from 'react-router-dom'
import ProductSelect from '../components/ProductSelect/ProductSelect'
import {kids} from '../api/shoeList.js'


export default function Kids() {
    const {id}= useParams();
    // console.log(id);
    
    return (
        <div>
            <h1>Shop Kids</h1>
            <Link to='/'><button>Home</button></Link>
            <ProductSelect data = {kids}></ProductSelect>
            <h1>ID is </h1>
        </div>
    )
}
