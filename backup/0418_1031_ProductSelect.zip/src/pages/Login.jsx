import React from 'react'
import { useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom'
import { login, logout} from '../store/modules/authSlice'

export default function Login() {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const handleLogin = () => {
        dispatch(login())
        navigate('/')
    }
    return (
        <div>
            <h1>Login Page</h1>
            <Link to='/'><button>Home</button></Link><br />
            <button onClick={handleLogin}>Log in</button>
            <button onClick={()=> dispatch(logout())}>Log out</button>
        </div>
    )
}
