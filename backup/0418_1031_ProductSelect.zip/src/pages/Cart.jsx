import React from 'react'
import { Link } from 'react-router-dom'


export default function Cart() {

    return (
        <div>
            <h1>Cart Page</h1>
            <Link to='/'><button>Home</button></Link>
        </div>
    )
}
