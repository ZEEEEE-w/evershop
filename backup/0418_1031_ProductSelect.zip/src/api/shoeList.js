
const kids = {
    id: 'kids',
    products: [
        {
            id: 'kids1',
            title: 'Coated glitter chuck taylor all star',
            price: 261,
            img: '/img/Coated glitter chuck taylor all star.png',
            brand: 'Converse',
            sku: '1234567890',
            color: 'Purple',
            size: ['M', 'L']
        },
        {
            id: 'kids2',
            title: 'Chuck taylor all star',
            price: 504,
            img: '../../img/Chuck taylor all star.png',
            brand: 'Nike',
            sku: '1234567891',
            color: 'Red',
            size: ['XS', 'S']
        },
        {
            id: 'kids3',
            title: 'Continental 80 shoes',
            price: 126,
            img: '../../img/Continental 80 shoes.png',
            brand: 'Adidas',
            sku: '1234567892',
            color: 'Pink',
            size: ['S', 'M']
        },
        {
            id: 'kids4',
            title: 'Swift run x shoes',
            price: 337,
            img: '../../img/Swift run x shoes.png',
            brand: 'Adidas',
            sku: '1234567893',
            color: 'Pink',
            size: ['X', 'L']
        },
        {
            id: 'kids5',
            title: 'Nmd r1 shoes',
            price: 537,
            img: '../../img/Nmd r1 shoes.png',
            brand: 'Adidas',
            sku: '1234567894',
            color: 'White',
            size: ['X', 'XL']
        }
    ]
}

export { kids }