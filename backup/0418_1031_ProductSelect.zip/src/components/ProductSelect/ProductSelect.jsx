import React from 'react'
import './ProductSelect.scss'
// import kids1 from '../../img/Coated_glitter_chuck_taylor_all_star.png'



export default function ProductSelect(props) {
    const item = props.data.products
    return (
        <div>
            <ul className='productList'>
                {item.map((product) => (
                    <li className='productItem' key={product.id}>
                        <a href={product.id} className='itemImg'>
                            <img src={product.img} alt={product.title} />
                        </a>
                        <a href="#" className="itemTitle">{product.title}</a>
                        <p className='itemPrice'>${product.price}</p>
                    </li>
                ))}
            </ul>
        </div>
    )
}
