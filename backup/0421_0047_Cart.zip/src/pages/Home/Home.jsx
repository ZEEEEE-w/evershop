import React from 'react'
import { Outlet, Link } from 'react-router-dom'
import './Home.scss'
import nike1 from '../../img/Nike_react_infinity_run_flyknit.png';
import nike2 from '../../img/Nike_court_vision_low.png';
import nike3 from '../../img/Nike_zoom_fly.png';
import nike4 from '../../img/Nike_air_zoom_pegasus_35.png';


export default function Layout() {
  return (
    <div>
      <div className='navigation'>
        <div className="naviLeft">
          <a href=" ">shop</a>
          <Link to='/about'><a>About Us</a></Link>
        </div>
        <div className="naviCenter">
          <a href="/"></a>
        </div>
        <div className="naviRight">
          <div>search</div>
          <div><Link to='/cart'><a>Cart</a></Link></div>
          <div><Link to='/login'><a>Login</a></Link></div>
        </div>
      </div>
      <div className="heading">
        <div className="headingLeft">
          <div className='headingLogo'></div>
        </div>
        <div className="headingRight">
          <h1>Your Heading Here</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ultricies sodales mi, at ornare elit semper ac.</p>
          <a href="">SHOP NOW</a>
        </div>
      </div>
      <div className="homeBody">
        <div className="container">
          <div className="collections">
            <div className="collection">
              <h3>Kids shoes collection</h3>
              <p>Constructed from luxury nylons, leathers, and custom hardware...</p>
              <Link to='/kids'><a className="btn" href="#">Shop Kids</a></Link>
            </div>
            <div className="collection">
              <h3>Women shoes collection</h3>
              <p>Constructed from luxury nylons, leathers, and custom hardware...</p>
              <Link to='/women'><a className="btn" href="#">Shop women</a></Link>
            </div>
            <div className="collection">
              <h3>Men shoes collection</h3>
              <p>Constructed from luxury nylons, leathers, and custom hardware...</p>
              <Link to='/men'><a className="btn" href="#">Shop men</a></Link>
            </div>
          </div>

          <h2 className="section-title">FEATURED PRODUCTS</h2>
          <div className="product-grid">
            <div className="product-card">
              <a href=""><img src={nike1} alt="Nike react"></img></a>
              <a href="" className="title">Nike react infinity run flyknit</a>
              <p className="price">$543.00</p>
            </div>
            <div className="product-card">
              <a href=""><img src={nike2} alt="Nike react"></img></a>
              <a href="" className="title">Nike court vision low</a>
              <p className="price">$904.00</p>
            </div>
            <div className="product-card">
              <a href=""><img src={nike3} alt="Nike react"></img></a>
              <a href="" className="title">Nike zoom fly</a>
              <p className="price">$930.00</p>
            </div>
            <div className="product-card">
              <a href=""><img src={nike4} alt="Nike react"></img></a>
              <a href="" className="title">Nike air zoom pegasus 35</a>
              <p className="price">$411.00</p>
            </div>
          </div>
        </div>
      </div>
      <div className="footer"></div>
      <Outlet />


    </div>
  )
}
