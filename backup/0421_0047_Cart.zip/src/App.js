import './App.css'
import RouteList from './router/routerIndex';

function App() {
  // const routes = useRoutes(router);
  return (
    <div className="App">
      <RouteList></RouteList>
    </div>
  );
}

export default App;